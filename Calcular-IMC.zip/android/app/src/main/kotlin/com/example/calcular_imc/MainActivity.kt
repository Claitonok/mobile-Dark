package com.example.calcular_imc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
