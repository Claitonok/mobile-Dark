package com.example.calcular_media

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
